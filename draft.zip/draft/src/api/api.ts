import * as fs from 'fs';
import * as path from 'path';
import * as vscode from 'vscode';
import { API_WS } from './re.api.ws';


export type RELanguageType = "auto" | "py" | "cs" | "uos";

export class REAPI{
    public static readonly SharedAPI = new REAPI('localhost',8765);

    public api = API_WS.getAPI();
    //public api = API_PB.getAPI();
    public is_open=false;
    constructor(
        public host:String,
        public port=8765
    ){

    }

    public open(){
        this.is_open = true;
        
    }

    public getScripts(){
        //Mok data 
        var cwd = __dirname;
        var scriptPaths = fs.readdirSync(cwd+'../scripts/');
        
        var scriptList: REScriptList = [];
        for(let fullpath in scriptPaths){
            scriptList.push(REScript.load(fullpath));
        }

        return scriptList;
    }
    
}





export type REScriptList = Array<REScript>;

export class REScript {
    public static load(fullpath:string){
        var script = new REScript(fullpath);

        script.content = fs.readFileSync(fullpath).toString();
        return script;
    }

    public is_loaded = false;
    constructor(
        public fullpath: string,
        public content?: string,
        public languageType: RELanguageType = "auto"
    ){
        vscode.window.showInformationMessage('REScript:constructor');
    }

}




// Messages
export type REMessageType = "REMessage"|"REMessageScriptList";


export class REMessage{
    public readonly messageType: REMessageType = "REMessage";
    
}


export class REMessageScriptList extends REMessage{
    public readonly messageType: REMessageType = "REMessageScriptList";

    public scriptList: Array<REScript> = [];
}





